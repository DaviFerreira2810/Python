from Python.ex111.utilidadescev import dado, moeda
