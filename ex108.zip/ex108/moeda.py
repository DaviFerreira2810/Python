# Crie um módulo chamado moeda.py que tenha as funções incorporadas aumentar(), diminuir(), dobro() e metade().
# Faça também um programa que importe esse módulo e use algumas dessas funções.


def aumentar(p=0):
    aumento = (p * 0.10) + p
    return aumento


def diminuir(p=0):
    reducao = p - (p * 0.13)
    return reducao


def dobro(p=0):
    dobrar = p * 2
    return dobrar


def metade(p=0):
    dividir2 = p / 2
    return dividir2


def moeda(p=0, m='R$'):
    return f'{m}{p:.2f}'.replace('.', ',')  # Vai retornar o valor substituindo "." por ","
