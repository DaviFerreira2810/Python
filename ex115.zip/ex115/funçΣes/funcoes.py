from time import sleep

cadastro = 'pessoascadastradas.txt'


def arquivoExiste(nome):
    try:
        a = open(nome, 'rt')
        a.close()
    except FileNotFoundError:
        return False
    else:
        return True


def menuPrincipal():
    listaMenu = ['Ver pessoas cadastradas', 'Cadastrar nova pessoa', 'Sair do Sistema']
    linhaCima()
    print(f'│{"MENU PRINCIPAL": ^40}│')
    linhaBaixo()
    c = 1
    for item in listaMenu:
        tam = len(item)
        if tam < 23:
            esp = (23 - len(item)) + 14
            print(f'│\033[33m{c} - \033[m\033[34m{item}\033[m{"│": >{esp}}')
        elif tam == 23:
            print(f'│\033[33m{c} - \033[m\033[34m{item}\033[m{"│": >{14}}')
        elif tam > 23:
            esp = 14 - (len(item) - 23)
            print(f'│\033[33m{c} - \033[m\033[34m{item}\033[m{"│": >{esp}}')
        c += 1
    linha()


def menuPrincipalOpcao():
    cont = 0
    while True:
        try:
            opcao = int(input('\033[93mSua Opção: \033[m'))
            if opcao > 3 or opcao == 0:
                print('\033[31mERRO! Digite uma opção valída!\033[m')
                cont += 1
                if cont == 2:
                    cont = 0
                    menuPrincipal()
                continue
        except ValueError:
            print('\033[31mERRO! Digite um número inteiro válido.\033[m')
            cont += 1
            if cont == 2:
                cont = 0
                menuPrincipal()
            continue
        except KeyboardInterrupt:
            print('\n\033[31m!!!ENTRADA DE DADOS INTERROMPIDA!!!\033[m')
            break
        else:
            if opcao == 1:
                opcao1()
                cont = 0
                sleep(1)
                menuPrincipal()
            elif opcao == 2:
                opcao2()
                cont = 0
                sleep(1)
                menuPrincipal()
            elif opcao == 3:
                opcao3()
                sleep(1)
                break


def opcao1():
    linhaCima()
    print(f'│{"PESSOAS CADASTRADAS": ^40}│')
    linhaBaixo()
    arquivo = open("pessoascadastradas.txt", "rt", encoding='utf-8')
    listas = arquivo.readlines()
    for c, a in enumerate(listas):
        dado = a.split(';')
        dado[1] = dado[1].replace('\n', '')
        print(f'│{dado[0]:<30}{dado[1]:>3} anos  │')
    arquivo.close()
    linha()


def opcao2():
    linhaCima()
    print(f'│{"NOVO CADASTRO": ^40}│')
    linha()
    while True:
        try:
            nome = str(input(f' Nome: ')).strip().title()
            if len(nome) > 30:
                print(' \033[31mNome muito grande, abrevie o nome!\033[m')
                continue
            if nome in '0123456789':
                print(' \033[31mERRO!!! Não pode conter números no Nome!\033[m')
                continue
        except KeyboardInterrupt:
            print('\n\033[31m!!!ENTRADA DE DADOS INTERROMPIDA!!!\033[m')
            break
        try:
            idade = leiaInt(f' Idade: ')
        except KeyboardInterrupt:
            print('\n\033[31m!!!ENTRADA DE DADOS INTERROMPIDA!!!\033[m')
            break
        cadastrar(cadastro, nome, idade)
        opc = str(input(' Continuar cadastrando [Sim/Não]: ')).lower().strip()
        if opc in 'ssim':
            continue
        else:
            break
    linha()


def opcao3():
    linhaCima()
    print(f'│{"     Saindo do Sistema..."}', end='')
    print(f'{" Até logo!"}     │')
    linha()


def leiaInt(msg):
    while True:
        try:
            n = str(input(msg)).strip()
            n = int(n)
        except (ValueError, TypeError):
            print('\033[5;49;31mERRO! Digite um número Válido.\033[m')
            continue
        except KeyboardInterrupt:
            print('\n\033[5;49;31mEntrada de dados Interrompida pelo usuário.\033[m')
            return 0
        else:
            return n


def cadastrar(arquivo, nome='desconhecido', idade=0):
    try:
        a = open(arquivo, 'at', encoding='utf-8')  # at = arquivo de texto
    except:
        print('Houve um erro na abertura do arquivo!')
    else:
        try:
            a.write(f'{nome};{idade}\n')
        except:
            print('Houve um erro ao adicionar os dados!')
        else:
            print(' Cadastro Realizado.!')
            a.close()


def linhaBaixo():
    print(f'├{"─" * 40}┤')


def linhaCima():
    print(f'┌{"─" * 40}┐')


def linha():
    print(f'└{"─" * 40}┘')


def linhaBasica():
    print(f' {"─" * 40}')
