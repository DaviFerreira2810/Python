from Python.ex115.funções import funcoes


arq = 'pessoascadastradas.txt'

while True:
    if funcoes.arquivoExiste(arq) is False:
        print('Não foi encontrado o arquivo de cadastros!')
        print('Tente Novamente!')
        a = open(arq, 'wt')
        a.close()
        break
    else:
        funcoes.menuPrincipal()
        funcoes.menuPrincipalOpcao()
        break
