# Crie um módulo chamado moeda.py que tenha as funções incorporadas aumentar(), diminuir(), dobro() e metade().
# Faça também um programa que importe esse módulo e use algumas dessas funções.


def aumentar(p=0, formato=False):
    aumento = (p * 0.10) + p
    return aumento if formato is False else moeda(aumento)  # Retornar aumento se formato está falso senão formatar
    # conforme a def moeda.


def diminuir(p=0, formato=False):
    reducao = p - (p * 0.13)
    return reducao if formato is False else moeda(reducao)


def dobro(p=0, formato=False):
    dobrar = p * 2
    return dobrar if formato is False else moeda(dobrar)


def metade(p=0, formato=False):
    dividir2 = p / 2
    return dividir2 if formato is False else moeda(dividir2)


def moeda(p=0, m='R$'):
    return f'{m}{p:.2f}'.replace('.', ',')  # Vai retornar o valor substituindo "." por ","
