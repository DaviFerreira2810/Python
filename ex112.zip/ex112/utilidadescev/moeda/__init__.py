# Crie um módulo chamado moeda.py que tenha as funções incorporadas aumentar(), diminuir(), dobro() e metade().
# Faça também um programa que importe esse módulo e use algumas dessas funções.


def aumentar(p=0, mais=10, formato=False):
    aumento = ((p / 100) * mais) + p
    return aumento if formato is False else moeda(aumento)  # Retornar aumento se formato está falso senão formatar
    # conforme a def moeda.


def diminuir(p=0, menos=13, formato=False):
    reducao = p - ((p / 100) * menos)
    return reducao if formato is False else moeda(reducao)


def dobro(p=0, formato=False):
    dobrar = p * 2
    return dobrar if formato is False else moeda(dobrar)


def metade(p=0, formato=False):
    dividir2 = p / 2
    return dividir2 if formato is False else moeda(dividir2)


def moeda(p=0, m='R$'):
    return f'{m}{p:.2f}'.replace('.', ',')  # Vai retornar o valor substituindo "." por ","


def resumo(p=0, a=0, b=0):
    print(f'{"-" * 31}\n{" RESUMO DO VALOR":^30}\n{"-" * 31}')
    print(f'Preço analisado: \t{moeda(p)}')
    print(f'Dobro do preço: \t{dobro(p, True)}')
    print(f'Metade do preço: \t{metade(p, True)}')
    print(f'{a}% de aumento: \t{aumentar(p, a, True)}')
    print(f'{b}% de redução: \t{diminuir(p, b, True)}')
    print(f'{"-" * 31}')
