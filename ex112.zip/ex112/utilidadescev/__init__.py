from Python.ex112.utilidadescev import dado, moeda
